
# BGSI Pet System

Sistema di hatch e pet stile Bubble Gum Simulator Infinity, creato in Roblox Studio.

## Funzionalità

- Hatch gratuito tramite input pet name
- Inventario pet con rarità e icone
- Pet che seguono il giocatore
- Salvataggio pet via DataStore

## Setup

1. Installa [Rojo](https://rojo.space/)
2. Apri Roblox Studio con il plugin Rojo attivo
3. Avvia `rojo serve`
4. Importa i modelli dei pet manualmente in ReplicatedStorage/Pets
